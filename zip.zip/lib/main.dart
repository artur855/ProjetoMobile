import 'package:flutter/material.dart';
import 'package:projetomobile/clinica_app.dart';

void main() => runApp(ClinicaApp());
